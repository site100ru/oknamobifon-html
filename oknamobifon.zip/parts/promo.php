<section class="promo">
  <div class="container">
    <h2 class="section__title">Акции</h2>
  </div>
</section>