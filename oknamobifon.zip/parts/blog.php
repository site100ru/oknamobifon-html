<section class="section section--blog">
	<div class="container">
		<h2 class="section__title">Блог — наши новости</h2>
	</div>
</section>