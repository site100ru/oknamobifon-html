<article <?php post_class(); ?>>

	<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>

</article>