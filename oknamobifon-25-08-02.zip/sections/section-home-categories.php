<section class="section home-categories">
  <div class="container">
    <div class="row">
      <div class="col-md-8 home-categories__item">
        <h3 class="home-categories__title"><strong>Пластиковые</strong> окна</h3>
        <p>Качественные пластиковые окна напрямую с завода по лучшей цене.</p>

        <a href="">Rehau</a>
        <a href="">KBE</a>
        <a href="">Novotex</a>
        <a href="">Proplex</a>
      </div>
      <div class="col-md-8 home-categories__item">
        <h3 class="home-categories__title"><strong>Деревянные</strong> окна</h3>
        <p>Качественные пластиковые окна напрямую с завода по лучшей цене.</p>

        <a href="">Rehau</a>
        <a href="">KBE</a>
        <a href="">Novotex</a>
        <a href="">Proplex</a>
      </div>
      <div class="col-md-8 home-categories__item">
        <h3 class="home-categories__title"><strong>Алюминиевые</strong> окна</h3>
        <p>Качественные пластиковые окна напрямую с завода по лучшей цене.</p>

        <a href="">Rehau</a>
        <a href="">KBE</a>
        <a href="">Novotex</a>
        <a href="">Proplex</a>
      </div>
    </div>
  </div>
</section>