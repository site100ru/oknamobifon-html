<section class="section section__main-hero">
  <div class="container">
    <h2 class="section__title">Выбирайте из лучших продуктов</h2>
  </div>
</section>